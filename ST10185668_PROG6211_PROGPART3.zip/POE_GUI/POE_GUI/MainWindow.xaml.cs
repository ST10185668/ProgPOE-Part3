﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeManagementApp
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    public partial class MainWindow : Window
    {
        private List<Recipe> recipes;

        public MainWindow()
        {
            InitializeComponent();
            InitializeRecipes();
            DisplayRecipes();
        }

        private void InitializeRecipes()
        {
            recipes = new List<Recipe>();
        }

        private void DisplayRecipes()
        {
            lstRecipes.ItemsSource = recipes.OrderBy(r => r.Name);
        }

        private void RecipeSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstRecipes.SelectedItem is Recipe selectedRecipe)
            {
                grpRecipeDetails.Visibility = Visibility.Visible;
                lstIngredients.ItemsSource = selectedRecipe.Ingredients;
                UpdateTotalCalories(selectedRecipe);
            }
            else
            {
                grpRecipeDetails.Visibility = Visibility.Collapsed;
                lstIngredients.ItemsSource = null; // Clear the ingredient list when no recipe is selected
                txtTotalCalories.Text = string.Empty; // Clear the total calories
            }
        }

        private void UpdateTotalCalories(Recipe recipe)
        {
            int totalCalories = recipe.Ingredients.Sum(i => i.Calories);
            txtTotalCalories.Text = totalCalories.ToString();

            if (totalCalories > 300)
            {
                MessageBox.Show("Warning: Total calories exceed 300!");
            }
        }

        private void FilterRecipes_Click(object sender, RoutedEventArgs e)
        {
            string filterIngredient = txtFilter.Text.Trim();
            string filterFoodGroup = cmbFoodGroup.Text.Trim();
            int maxCalories = 0;

            if (!string.IsNullOrEmpty(txtMaxCalories.Text.Trim()))
            {
                if (!int.TryParse(txtMaxCalories.Text.Trim(), out maxCalories))
                {
                    MessageBox.Show("Invalid input for maximum calories. Please enter a valid number.");
                    return;
                }
            }

            var filteredRecipes = recipes.Where(r => r.Ingredients.Any(i => (string.IsNullOrEmpty(filterIngredient) || i.Name.Contains(filterIngredient)) && (string.IsNullOrEmpty(filterFoodGroup) || i.FoodGroup.Contains(filterFoodGroup))) && (maxCalories == 0 || r.Ingredients.Sum(i => i.Calories) <= maxCalories));



            lstRecipes.ItemsSource = filteredRecipes.OrderBy(r => r.Name);
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            string ingredientName = txtIngredientName.Text.Trim();
            string foodGroup = cmbIngredientFoodGroup.Text.Trim();
            int calories;

            if (string.IsNullOrEmpty(ingredientName) || string.IsNullOrEmpty(foodGroup) || !int.TryParse(txtIngredientCalories.Text.Trim(), out calories))
            {
                MessageBox.Show("Please enter valid ingredient details.");
                return;
            }

            Ingredient ingredient = new Ingredient
            {
                Name = ingredientName,
                Calories = calories,
                FoodGroup = foodGroup
            };

            if (lstRecipes.SelectedItem is Recipe selectedRecipe)
            {
                selectedRecipe.Ingredients.Add(ingredient);
                lstIngredients.ItemsSource = selectedRecipe.Ingredients;
                UpdateTotalCalories(selectedRecipe);
            }
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = txtRecipeName.Text.Trim();

            if (string.IsNullOrEmpty(recipeName))
            {
                MessageBox.Show("Please enter a valid recipe name.");
                return;
            }

            Recipe recipe = new Recipe
            {
                Name = recipeName,
                Ingredients = new List<Ingredient>()
            };

            recipes.Add(recipe);
            DisplayRecipes(); // Update the displayed list of recipes
        }
    }
}
