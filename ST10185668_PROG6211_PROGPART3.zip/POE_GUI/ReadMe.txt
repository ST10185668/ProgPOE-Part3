Read me:


1. Unzip zip file
2. Open PEO_GUI...This will take you to Microsoft Visual Studio
3. Once in Visual Studio Debug and run the code
4. First prompt is to enter the name of your recipe
5. The next prompt will be to enter the ingredients of your recipe
6. Then you will follow the next prompts and enter the required information
7. Once you enter the infor to filter, the corresponding recipe will be displayed
8. You can add as many recipes as you want